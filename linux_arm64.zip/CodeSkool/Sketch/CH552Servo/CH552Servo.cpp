#include <Arduino.h>
#include <CH552Servo.h>

int CH_SERVO_MIN_PULSE_WIDTH = 500;
int CH_SERVO_MAX_PULSE_WIDTH = 2500;
uint8_t CH_SERVO_MIN_ANGLE = 0;
uint8_t CH_SERVO_MAX_ANGLE = 180;

void servoConfig(int minPulse, int maxPulse, uint8_t minAngle, uint8_t maxAngle) {
  CH_SERVO_MIN_PULSE_WIDTH = minPulse;
  CH_SERVO_MAX_PULSE_WIDTH = maxPulse;
  CH_SERVO_MIN_ANGLE = minAngle;
  CH_SERVO_MAX_ANGLE = maxAngle;
}

void servoWrite(uint8_t servoPin, uint8_t angle) {
  angle = (CH_SERVO_MAX_ANGLE - angle) + CH_SERVO_MIN_ANGLE;
  int pulse = map(angle, CH_SERVO_MIN_ANGLE, CH_SERVO_MAX_ANGLE, CH_SERVO_MIN_PULSE_WIDTH, CH_SERVO_MAX_PULSE_WIDTH);
  digitalWrite(servoPin, HIGH);
  delayMicroseconds(pulse); // Duration of the pusle in microseconds
  digitalWrite(servoPin, LOW);
  delayMicroseconds(18550); // 20ms - duration of the pusle
}
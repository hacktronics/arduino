from picozero import pico_led
from time import sleep

while True:
    pico_led.toggle()
    sleep(1)

#ifndef CH552_Servo_h
#define CH552_Servo_h

void servoConfig(int minPulse, int maxPulse, uint8_t minAngle, uint8_t maxAngle);
void servoWrite(uint8_t servoPin, uint8_t angle);

#endif

var searchData=
[
  ['copyright_0',['Copyright',['../page_copyright.html',1,'index']]]
];

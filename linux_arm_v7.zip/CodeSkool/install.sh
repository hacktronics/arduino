#!/bin/bash
./arduino-cli config init
./arduino-cli core update-index --config-file arduino-cli.yaml
./arduino-cli core install esp32:esp32 --config-file arduino-cli.yaml
./arduino-cli core install arduino:avr --config-file arduino-cli.yaml
./arduino-cli core install arduino:mbed_rp2040 --config-file arduino-cli.yaml
./arduino-cli core install CH55xDuino:mcs51 --config-file arduino-cli.yaml
./arduino-cli board list
./arduino-cli compile --fqbn esp32:esp32:esp32 --libraries Sketch Sketch/Sketch.ino
